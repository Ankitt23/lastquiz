import sqlite3

def add_admin_user():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    # Define admin credentials
    admin_username = "admin"
    admin_password = "admin123"  # Replace with your preferred password

    # Check if admin user already exists
    cursor.execute("SELECT * FROM users WHERE username = ?", (admin_username,))
    if cursor.fetchone():
        print("Admin user already exists!")
    else:
        # Insert admin user into the database
        cursor.execute("INSERT INTO users (username, password) VALUES (?, ?)", (admin_username, admin_password))
        conn.commit()
        print("Admin user added successfully!")

    conn.close()

# Run the script
add_admin_user()
