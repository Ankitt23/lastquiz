from flask import Flask, render_template, request, redirect, url_for, session
import sqlite3

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # For session management (e.g., login)

# Database connection
def connect_db():
    return sqlite3.connect('database.db')

@app.route('/')
def home():
    """Render the homepage with dynamic Login/Logout button and username display."""
    user_logged_in = 'user' in session  # Check if the user is logged in
    return render_template('home.html', user_logged_in=user_logged_in)

@app.route('/quiz-history')
def quiz_history():
    if 'user_id' not in session:
        return redirect(url_for('login'))  # Redirect only if not logged in

    user_id = session['user_id']
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT quiz_type, score, date_taken
        FROM quiz_results
        WHERE user_id = ?
        ORDER BY date_taken DESC
    ''', (user_id,))
    history = cursor.fetchall()
    conn.close()

    return render_template('quiz_history.html', username=session['user'], history=history)

#admin view user route
@app.route('/admin/users')
def view_all_users():
    """View all registered users."""
    # Ensure only admins can access
    if 'user' not in session or session['user'] != 'admin':
        return redirect(url_for('login'))

    conn = connect_db()
    cursor = conn.cursor()

    # Fetch all users with their passwords from the database
    cursor.execute("SELECT id, username, password FROM users")
    users = cursor.fetchall()
    conn.close()

    return render_template('view_users.html', users=users)

#admin delete route
@app.route('/admin/delete', methods=['POST'])
def delete_question():
    """Delete a question from the database."""
    if 'user' not in session or session['user'] != 'admin':  # Ensure only admin can access
        return redirect(url_for('login'))

    question_id = request.form.get('question_id')

    if question_id:
        conn = connect_db()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM questions WHERE id = ?", (question_id,))
        conn.commit()
        conn.close()

    return redirect(url_for('admin'))

#admin edit route
@app.route('/admin/edit', methods=['GET', 'POST'])
def edit_question():
    """Edit a question in the database."""
    if 'user' not in session or session['user'] != 'admin':  # Ensure only admin can access
        return redirect(url_for('login'))

    if request.method == 'POST':
        # Update the question in the database
        question_id = request.form.get('question_id')
        question = request.form.get('question')
        option_a = request.form.get('option_a')
        option_b = request.form.get('option_b')
        option_c = request.form.get('option_c')
        option_d = request.form.get('option_d')
        correct_option = request.form.get('correct_option')
        quiz_type = request.form.get('quiz_type')

        conn = connect_db()
        cursor = conn.cursor()
        cursor.execute('''
        UPDATE questions
        SET question = ?, option_a = ?, option_b = ?, option_c = ?, option_d = ?, correct_option = ?, type = ?
        WHERE id = ?
        ''', (question, option_a, option_b, option_c, option_d, correct_option, quiz_type, question_id))
        conn.commit()
        conn.close()

        return redirect(url_for('admin'))

    # Render the edit form with existing question data
    question_id = request.args.get('question_id')
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM questions WHERE id = ?", (question_id,))
    question = cursor.fetchone()
    conn.close()

    return render_template('edit_question.html', question=question)


#admin route
@app.route('/admin', methods=['GET', 'POST'])
def admin():
    """Admin page for managing quiz questions."""
    if 'user' not in session or session['user'] != 'admin':  # Ensure only 'admin' can access
        return redirect(url_for('login'))

    conn = connect_db()
    cursor = conn.cursor()

    if request.method == 'POST':
        # Safely retrieve form data
        quiz_type = request.form.get('quiz_type')  # 'student' or 'college'
        question = request.form.get('question')
        option_a = request.form.get('option_a')
        option_b = request.form.get('option_b')
        option_c = request.form.get('option_c')
        option_d = request.form.get('option_d')
        correct_option = request.form.get('correct_option')

        # Validate input
        if not all([quiz_type, question, option_a, option_b, option_c, option_d, correct_option]):
            return "All fields are required!", 400

        # Insert the question into the database
        cursor.execute('''
        INSERT INTO questions (question, option_a, option_b, option_c, option_d, correct_option, type)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (question, option_a, option_b, option_c, option_d, correct_option, quiz_type))
        conn.commit()

    # Fetch all questions to display on the admin page
    cursor.execute("SELECT id, question, type FROM questions")
    questions = cursor.fetchall()
    conn.close()

    return render_template('admin.html', questions=questions)


#quiz route
@app.route('/quiz', methods=['GET', 'POST'])
def quiz():
    """Render quiz questions with pagination and handle quiz submissions."""
    if 'user' not in session:
        return redirect(url_for('login'))

    quiz_type = request.args.get('type', 'student')  # Default to 'student'
    page = int(request.args.get('page', 1))  # Current page, defaults to 1
    questions_per_page = 4  # Number of questions per page

    conn = connect_db()
    cursor = conn.cursor()

    if request.method == 'POST':
        # Handle quiz submission
        user_answers = request.form
        cursor.execute("SELECT id, question, option_a, option_b, option_c, option_d, correct_option FROM questions WHERE type = ?", (quiz_type,))
        questions = cursor.fetchall()
        conn.close()

        score = 0
        results = []  # Store results for display

        for question in questions:
            question_id, question_text, option_a, option_b, option_c, option_d, correct_option = question
            user_answer = user_answers.get(str(question_id))

            # Check if the answer is correct
            is_correct = (user_answer == correct_option)
            if is_correct:
                score += 1

            # Add question details to results
            results.append({
                'question': question_text,
                'user_answer': user_answer,
                'correct_answer': correct_option,
                'options': {
                    'a': option_a,
                    'b': option_b,
                    'c': option_c,
                    'd': option_d,
                },
                'is_correct': is_correct
            })

        # Save the quiz result to the database
        if 'user_id' in session:
            user_id = session['user_id']
            conn = connect_db()
            cursor = conn.cursor()
            cursor.execute('''
            INSERT INTO quiz_results (user_id, quiz_type, score)
            VALUES (?, ?, ?)
            ''', (user_id, quiz_type, score))
            conn.commit()
            conn.close()

        # Render the result page with the score and results
        return render_template('result.html', score=score, results=results, total=len(questions))

    # Fetch all questions for the selected quiz type
    cursor.execute("SELECT id, question, option_a, option_b, option_c, option_d FROM questions WHERE type = ?", (quiz_type,))
    all_questions = cursor.fetchall()
    conn.close()

    # Paginate questions
    total_questions = len(all_questions)
    start = (page - 1) * questions_per_page
    end = start + questions_per_page
    paginated_questions = all_questions[start:end]

    # Calculate total pages
    total_pages = (total_questions + questions_per_page - 1) // questions_per_page

    # Render the quiz page
    return render_template(
        'quiz.html',
        questions=paginated_questions,
        quiz_type=quiz_type,
        page=page,
        total_pages=total_pages
    )

#result route
@app.route('/result/<int:score>')
def result(score):
    """Render the result page showing the user's score."""
    return render_template('result.html', score=score)

#user login
@app.route('/login', methods=['GET', 'POST'])
def login():
    """Render login page and handle login functionality."""
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Validate user credentials
        conn = connect_db()
        cursor = conn.cursor()
        cursor.execute("SELECT id, username FROM users WHERE username = ? AND password = ?", (username, password))
        user = cursor.fetchone()
        conn.close()

        if user:
            session['user_id'] = user[0]  # Store user ID in session
            session['user'] = user[1]    # Store username in session
            next_page = request.args.get('next')
            return redirect(next_page or url_for('home'))
        else:
            return render_template('login.html', error="Invalid username or password")

    return render_template('login.html')

#user register
@app.route('/register', methods=['GET', 'POST'])
def register():
    """Render registration page and handle new user registration."""
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Insert new user into the database
        conn = connect_db()
        cursor = conn.cursor()
        try:
            cursor.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, password))
            conn.commit()
            conn.close()
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            conn.close()
            return render_template('register.html', error="Username already exists!")

    return render_template('register.html')

#user logout
@app.route('/logout')
def logout():
    """Logout the user by clearing the session."""
    session.pop('user', None)
    return redirect(url_for('home'))


if __name__ == '__main__':
    app.run(debug=True)
